<?php

return [
    'dates_validated' => 'मिति सहि छन् र तिरेको डेटाबेसमा राखियो!',
    'end_date_invalid' => 'समाप्त मिति सुरु मितिबाट पछि वा त्यसको बराबर हुनुपर्छ।',
    'Start Date' => 'सुरुको मिति',
    'End Date' => 'अन्तिम मिति',
    'Submit' => 'पेश गर्नुहोस्',
    'Date Validation Form' => 'मिति मान्यता फारम',
    'Language' => 'भाषा',
    'English' => 'अंग्रेजी',
    'Nepali' => 'नेपाली',
    'Hindi' => 'हिंदी',
];
